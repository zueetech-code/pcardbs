import * as React from 'react'
import { Slot } from '@radix-ui/react-slot'
import { cva, type VariantProps } from 'class-variance-authority'

import { cn } from '@/lib/utils'

const badgeVariants = cva(
  'inline-flex items-center justify-center rounded-full border px-3 py-1 text-xs font-semibold w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1.5 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-all duration-200 overflow-hidden uppercase tracking-wide',
  {
    variants: {
      variant: {
        default:
          'border-primary/40 bg-primary/15 text-primary [a&]:hover:bg-primary/25 [a&]:hover:border-primary/60',
        secondary:
          'border-secondary/30 bg-secondary/40 text-secondary-foreground [a&]:hover:bg-secondary/60',
        destructive:
          'border-destructive/40 bg-destructive/15 text-destructive [a&]:hover:bg-destructive/25 [a&]:hover:border-destructive/60 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40',
        outline:
          'border-border/60 text-foreground [a&]:hover:bg-accent/30 [a&]:hover:border-accent/40 [a&]:hover:text-accent-foreground',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
)

function Badge({
  className,
  variant,
  asChild = false,
  ...props
}: React.ComponentProps<'span'> &
  VariantProps<typeof badgeVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : 'span'

  return (
    <Comp
      data-slot="badge"
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    />
  )
}

export { Badge, badgeVariants }
